import time

from clearconsole import clear


def Clear():
    clear()


def Clears():
    print('Example')
    time.sleep(2)
    clear()
    time.sleep(2)


if __name__ == '__main__':
    Clear()
